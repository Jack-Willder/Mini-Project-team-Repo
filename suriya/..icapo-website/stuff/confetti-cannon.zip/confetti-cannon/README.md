# Confetti Cannon

A Pen created on CodePen.

Original URL: [https://codepen.io/jscottsmith/pen/VjPaLO](https://codepen.io/jscottsmith/pen/VjPaLO).

Click, drag & release to shoot canvas confetti particles. Uses the GreenSock Physics2d plugin.