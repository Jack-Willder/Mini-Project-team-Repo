# THE CONFETTI ANIMATION

A Pen created on CodePen.

Original URL: [https://codepen.io/iprodev/pen/azpWBr](https://codepen.io/iprodev/pen/azpWBr).

Smooth, sleek, responsive and retina ready confetti animation effect. There are two types of confetti, the traditional pieces of ‘paper’ and a ribbon type that wiggles its way down the screen. The ribbon confetti uses a physics simulation for the motion while the paper confetti is animated using sine functions.